---
layout: blog
title: Kirki 3.0 coming soon!
---


Redirecting you to the article...
<script>
window.location = "http://aristath.github.io/wordpress/customizer/2017/03/26/kirki-3.html";
</script>