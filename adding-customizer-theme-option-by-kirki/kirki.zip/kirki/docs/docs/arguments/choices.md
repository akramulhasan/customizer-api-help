---
layout: default
title: choices
published: true
mainMaxWidth: 50rem;
---

The `choices` argument allows you to select the available choices for a control and is always formatted as an array.

For more specific info and usage instructions please refer to the documentation of individual controls.
